# Hicks Help — personal browser testing update

Version 1.0.1. Upload this to the existing personal testing plugin's Upload new version dialog in ChatGPT. The package retains its exported internal name (dev-6abfd65360c08191a60b89fbe27f0024) and registered browser app connection.

Includes HAR's logo, company name, public support/legal links and starter prompts. No local server or desktop executable is included.

The public hicks-help submission is separate and has already been submitted according to the owner. Do not upload this personal update to that submission.
